const form = document.querySelector("#brief");
const statusEl = document.querySelector("#status");
const resultEl = document.querySelector("#result");
const noteEl = document.querySelector("#resultNote");
const buttons = ["copy", "download", "preview"].map(id => document.getElementById(id));
let latestHTML = "";

const value = id => document.getElementById(id).value.trim();

form.addEventListener("submit", async event => {
  event.preventDefault();
  if (!value("mainKeyword")) return;
  const generate = document.getElementById("generate");
  generate.disabled = true;
  statusEl.textContent = "Generating. This may take a few minutes...";
  resultEl.textContent = "Working on your article...";
  noteEl.textContent = "";
  buttons.forEach(button => button.disabled = true);

  const payload = {
    brand: value("brand"), country: value("country"), language: value("language"),
    mainKeyword: value("mainKeyword"), additionalKeywords: value("additionalKeywords"),
    faqs: value("faqs"), wordCount: value("wordCount"),
    officialPhone: value("officialPhone"), officialSource: value("officialSource"),
    ownTfn: value("ownTfn"), customInstructions: value("customInstructions")
  };

  try {
    const response = await fetch("/api/generate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Request failed");
    latestHTML = data.html;
    resultEl.textContent = latestHTML;
    noteEl.textContent = data.note || "";
    buttons.forEach(button => button.disabled = false);
    statusEl.textContent = "Article generated. Please fact-check before publishing.";
  } catch (error) {
    resultEl.textContent = "Could not generate the article.";
    statusEl.textContent = error.message;
  } finally {
    generate.disabled = false;
  }
});

document.getElementById("copy").addEventListener("click", async () => {
  await navigator.clipboard.writeText(latestHTML);
  noteEl.textContent = "HTML copied.";
});
document.getElementById("download").addEventListener("click", () => {
  const blob = new Blob([latestHTML], { type: "text/html;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = "zain-ai-article.html"; a.click();
  URL.revokeObjectURL(url);
});
document.getElementById("preview").addEventListener("click", () => {
  const win = window.open("", "_blank", "noopener,noreferrer");
  if (!win) { noteEl.textContent = "Allow pop-ups to preview the article."; return; }
  win.document.open();
  win.document.write(latestHTML);
  win.document.close();
});
