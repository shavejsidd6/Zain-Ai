# ZAIN AI — GitHub-ready starter

This is a full-stack starter, not a finished production SEO platform.

## Included
- Public-facing article brief form
- Server-side OpenAI Responses API integration
- Optional model web search (`ENABLE_WEB_RESEARCH=true`)
- Country, language, keyword, FAQ and custom instruction inputs
- User-supplied airline phone number + official source URL fields
- HTML copy/download and preview
- Basic security headers and generation rate limit

## Not included yet
- Google Ads Keyword Planner / historical search-volume integration
- Direct Google People Also Ask scraping (do not scrape Google in violation of its terms)
- Guaranteed 10,000-word single-pass output; very long articles may need section-by-section generation
- User accounts, billing, database, CAPTCHA, per-user quotas or admin dashboard
- Automatic verification of airline phone numbers
- Google indexing/rank tracking (intentionally excluded)

## Run locally
1. Install Node.js 20 or newer.
2. Copy `.env.example` to `.env`.
3. Add your API key to `.env`.
4. Run `npm install`.
5. Run `npm start`.
6. Open `http://localhost:3000`.

Never commit `.env` or put API keys in `public/`.

## Deploy
GitHub stores your source code; it does not run this Node server by itself. Keep the repository private and deploy this Node app to a Node-compatible host (for example Render, Railway, or another backend host). Add `OPENAI_API_KEY`, `OPENAI_MODEL`, `ENABLE_WEB_RESEARCH`, and `PORT` in the host's environment settings. The deployed app URL can be public.

If you use GitHub Pages, it can host only the static frontend; the API must still run on a separate backend host. For this project, deploy the complete Node app to a backend host.

## Public launch checklist
- Add login or usage controls if generation should be limited to approved users.
- Add CAPTCHA and stronger abuse protection before public launch.
- Set provider spending limits and monitor usage.
- Add a privacy policy and terms of use.
- Confirm that you have permission to publish any airline brand assets or partner contact details.
- Verify every airline policy and phone number from the airline's official website before publication.

## Phone-number policy
The tool deliberately does not repeat a TFN every 20 words. That would make content spammy and hard to read. Use verified contact details in a clearly labelled contact section and relevant call-to-action. Never label your own support number as an airline's official number.

## API reference
Uses the OpenAI Responses API. See:
https://developers.openai.com/api/reference/resources/responses/methods/create
