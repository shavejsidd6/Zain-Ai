import "dotenv/config";
import express from "express";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import OpenAI from "openai";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const port = Number(process.env.PORT || 3000);

app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      imgSrc: ["'self'", "data:"],
      connectSrc: ["'self'"],
      objectSrc: ["'none'"],
      upgradeInsecureRequests: []
    }
  }
}));
app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

const generationLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 5,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: { error: "Too many generation requests. Please wait 15 minutes and try again." }
});

function clean(value, max = 5000) {
  return String(value ?? "").trim().slice(0, max);
}

app.get("/api/health", (_req, res) => res.json({ ok: true, app: "ZAIN AI" }));

app.post("/api/generate", generationLimiter, async (req, res) => {
  try {
    if (!process.env.OPENAI_API_KEY) {
      return res.status(503).json({ error: "AI service is not configured. Add OPENAI_API_KEY to the hosting environment." });
    }

    const data = {
      brand: clean(req.body.brand, 160),
      country: clean(req.body.country, 120),
      language: clean(req.body.language, 80),
      mainKeyword: clean(req.body.mainKeyword, 300),
      additionalKeywords: clean(req.body.additionalKeywords, 3000),
      faqs: clean(req.body.faqs, 5000),
      customInstructions: clean(req.body.customInstructions, 3000),
      officialPhone: clean(req.body.officialPhone, 100),
      officialSource: clean(req.body.officialSource, 500),
      ownTfn: clean(req.body.ownTfn, 100),
      wordCount: Math.min(10000, Math.max(1000, Number(req.body.wordCount) || 3000))
    };

    if (!data.mainKeyword) return res.status(400).json({ error: "Please enter a main keyword." });

    const researchEnabled = process.env.ENABLE_WEB_RESEARCH !== "false";
    const instructions = `You are ZAIN AI, an SEO content assistant. Write original, useful, reader-first Google SEO content.
Rules:
- Write in ${data.language || "English"} for ${data.country || "the selected target market"}.
- Never promise rankings, Google AI Overview inclusion, fast indexing, or guaranteed traffic.
- Never invent airline policies, phone numbers, prices, baggage allowances, fees, URLs, or opening hours.
- If web research is enabled, use it to verify current claims and prefer official airline/government sources. Clearly mark facts that could not be verified.
- Use supplied phone numbers only. The official airline phone number is supplied by the user and must be shown only with the supplied official source URL. If the source URL is missing, label it "user-provided number — verify before publishing", not official.
- The user's own TFN/support number is not an airline number. If supplied, identify it as independent/authorized support only when the user confirms authorization; never imply it is the airline's official number.
- Do NOT insert phone numbers every 20 words. Put verified contact details in a clear contact/help section and a relevant CTA, without keyword stuffing.
- Include SEO title, meta description, suggested slug, one H1, logical H2/H3 headings, introduction, detailed body, FAQs, conclusion, and a short sources section with URLs where available.
- Naturally cover every supplied keyword and answer every supplied FAQ. Avoid repetitive keyword stuffing.
- Output clean HTML only, using semantic tags. Do not include markdown fences.
- Target approximately ${data.wordCount} words; if the requested length cannot fit in one response, produce a complete useful draft and state that it is a first part in an HTML comment.`;

    const userInput = `Create an SEO article using this brief:
Brand / airline: ${data.brand || "Not specified"}
Target country: ${data.country || "All countries"}
Main keyword: ${data.mainKeyword}
Additional keywords (cover naturally): ${data.additionalKeywords || "Suggest relevant supporting terms"}
FAQs to answer: ${data.faqs || "Research relevant FAQs"}
Official airline phone number supplied by user: ${data.officialPhone || "Not supplied"}
Official source URL supplied by user: ${data.officialSource || "Not supplied"}
User's own TFN/support number: ${data.ownTfn || "Not supplied"}
Custom instructions: ${data.customInstructions || "None"}
Before writing, research current relevant facts using web search if enabled. Do not fabricate historical keyword volumes or claim exact Google search volume unless a connected data provider supplies it.`;

    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const payload = {
      model: process.env.OPENAI_MODEL || "gpt-6-astra",
      instructions,
      input: userInput,
      max_output_tokens: 16000
    };
    if (researchEnabled) payload.tools = [{ type: "web_search" }];

    const response = await client.responses.create(payload);
    const html = response.output_text || "";
    if (!html) return res.status(502).json({ error: "The AI returned an empty response. Please try again." });

    res.json({
      html,
      model: payload.model,
      researchEnabled,
      note: "Review all airline policies and phone details against official sources before publishing."
    });
  } catch (error) {
    console.error("Generation error:", error?.message || error);
    res.status(500).json({ error: "Article generation failed. Check the server logs and API configuration." });
  }
});

app.get("*", (_req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

app.listen(port, () => console.log(`ZAIN AI running on http://localhost:${port}`));
